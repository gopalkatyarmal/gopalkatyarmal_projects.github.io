/**
 * Initial Bootstrap Tooltip.
 */
export function loadTooptip() {
  $('[data-toggle="tooltip"]').tooltip();
}
